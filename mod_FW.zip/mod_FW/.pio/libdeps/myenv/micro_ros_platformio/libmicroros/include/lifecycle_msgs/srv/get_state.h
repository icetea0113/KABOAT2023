// generated from rosidl_generator_c/resource/idl.h.em
// with input from lifecycle_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__SRV__GET_STATE_H_
#define LIFECYCLE_MSGS__SRV__GET_STATE_H_

#include "lifecycle_msgs/srv/detail/get_state__struct.h"
#include "lifecycle_msgs/srv/detail/get_state__functions.h"
#include "lifecycle_msgs/srv/detail/get_state__type_support.h"

#endif  // LIFECYCLE_MSGS__SRV__GET_STATE_H_
