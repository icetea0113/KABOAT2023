// generated from rosidl_generator_c/resource/idl.h.em
// with input from action_msgs:msg/GoalStatusArray.idl
// generated code does not contain a copyright notice

#ifndef ACTION_MSGS__MSG__GOAL_STATUS_ARRAY_H_
#define ACTION_MSGS__MSG__GOAL_STATUS_ARRAY_H_

#include "action_msgs/msg/detail/goal_status_array__struct.h"
#include "action_msgs/msg/detail/goal_status_array__functions.h"
#include "action_msgs/msg/detail/goal_status_array__type_support.h"

#endif  // ACTION_MSGS__MSG__GOAL_STATUS_ARRAY_H_
