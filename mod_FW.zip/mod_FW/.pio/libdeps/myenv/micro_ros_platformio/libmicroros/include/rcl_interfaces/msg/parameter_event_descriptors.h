// generated from rosidl_generator_c/resource/idl.h.em
// with input from rcl_interfaces:msg/ParameterEventDescriptors.idl
// generated code does not contain a copyright notice

#ifndef RCL_INTERFACES__MSG__PARAMETER_EVENT_DESCRIPTORS_H_
#define RCL_INTERFACES__MSG__PARAMETER_EVENT_DESCRIPTORS_H_

#include "rcl_interfaces/msg/detail/parameter_event_descriptors__struct.h"
#include "rcl_interfaces/msg/detail/parameter_event_descriptors__functions.h"
#include "rcl_interfaces/msg/detail/parameter_event_descriptors__type_support.h"

#endif  // RCL_INTERFACES__MSG__PARAMETER_EVENT_DESCRIPTORS_H_
