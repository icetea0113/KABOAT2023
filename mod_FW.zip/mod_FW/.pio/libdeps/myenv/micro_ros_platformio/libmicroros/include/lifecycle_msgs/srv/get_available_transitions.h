// generated from rosidl_generator_c/resource/idl.h.em
// with input from lifecycle_msgs:srv/GetAvailableTransitions.idl
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__SRV__GET_AVAILABLE_TRANSITIONS_H_
#define LIFECYCLE_MSGS__SRV__GET_AVAILABLE_TRANSITIONS_H_

#include "lifecycle_msgs/srv/detail/get_available_transitions__struct.h"
#include "lifecycle_msgs/srv/detail/get_available_transitions__functions.h"
#include "lifecycle_msgs/srv/detail/get_available_transitions__type_support.h"

#endif  // LIFECYCLE_MSGS__SRV__GET_AVAILABLE_TRANSITIONS_H_
