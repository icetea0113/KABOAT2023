---
name: General issue
about: General issue template for micro-ROS
title: ''
labels: ''
assignees: ''

---

## Issue template

- Hardware description: <!-- hardware where you are using micro-ROS -->
- RTOS: <!-- RTOS where you are using micro-ROS -->
- Installation type: <!-- micro_ros_setup, modules, etc  -->
- Version or commit hash: <!-- version of micro-ROS used: foxy, rolling  -->

#### Steps to reproduce the issue
<!-- Detailed instructions on how to reliably reproduce this issue http://sscce.org/-->

#### Expected behavior

#### Actual behavior

#### Additional information
